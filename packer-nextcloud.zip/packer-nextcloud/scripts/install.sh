#!bin/bash
sudo -u ncadmin echo "nextcloud"| sudo bash /tmp/nextcloud_install_production.sh
wait
exit
